# ChangeLog

## v0.1.2 - 2025-01-23

### Enhancements:

* feat(memory): add print memory info
* feat(log & memory): split helper functions and macros

## v0.1.1

### Enhancements:

* feat(repo): update config header and Kconfig files

## v0.1.0

### Enhancements:

* feat(repo): initialize with modules 'check', 'log' and 'utils'
