/*
 * SPDX-FileCopyrightText: 2023-2025 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#pragma once

#warning "This file is Deprecated. Please use the `esp_display_panel.hpp` file instead."

#include "esp_display_panel.hpp"
